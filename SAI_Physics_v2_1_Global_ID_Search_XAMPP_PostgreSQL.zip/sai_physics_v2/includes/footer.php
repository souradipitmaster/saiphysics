    </main><footer class="footer"><span>© <?= date('Y') ?> SAI Physics</span><span>Built for focused learning <b>✦</b></span></footer>
  </section>
</div><script src="assets/app.js" defer></script><script src="assets/install.js" defer></script></body></html>
