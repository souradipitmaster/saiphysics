<?php
require_once __DIR__ . '/../app/bootstrap.php';
$me = current_user(); $role = current_role(); $tenantRow = current_tenant_row();
$titleText = $page_title ?? APP_NAME; $flashMessage = get_flash();
$myLoginCode = '';
if ($role === 'teacher') { $cq=db()->prepare('SELECT teacher_code FROM users WHERE id=?'); $cq->execute(array((int)$me['id'])); $myLoginCode=(string)$cq->fetchColumn(); }
elseif ($role === 'student') { $cq=db()->prepare('SELECT sr.student_code FROM students s JOIN student_registry sr ON sr.id=s.registry_id WHERE s.user_id=? ORDER BY s.created_at DESC LIMIT 1'); $cq->execute(array((int)$me['id'])); $myLoginCode=(string)$cq->fetchColumn(); }
$headerSessions = array(); $headerCurrentSessionId = 0;
if ($role === 'super_admin' && $tenantRow) { $sq=db()->prepare('SELECT id,name FROM sessions WHERE tenant_id=? ORDER BY start_date DESC,id DESC'); $sq->execute(array((int)$tenantRow['id'])); $headerSessions=$sq->fetchAll(); $headerCurrentSessionId=current_session_id(); }
$navItems = array();
if ($role === 'super_admin') $navItems[] = array('tenants.php','▦','Institutes');
if (in_array($role, array('super_admin','admin','teacher','student'), true)) $navItems[] = array('global_search.php','⌕','Global ID Search');
if (in_array($role, array('super_admin','admin'), true)) {
    $navItems[] = array('index.php','⌂','Dashboard');
    if (current_tenant()) {
        $navItems = array_merge($navItems, array(array('sessions.php','◷','Sessions'),array('batches.php','▤','Batches'),array('teachers.php','♙','Teachers'),array('students.php','♧','Students'),array('fees.php','₹','Fees'),array('payments.php','↗','Payments'),array('classroom.php','▣','Classrooms'),array('attendance.php','✓','Attendance'),array('exams.php','✎','Tests & Marks')));
    }
} elseif ($role === 'teacher') {
    $navItems = array(array('index.php','⌂','Dashboard'),array('batches.php','▤','My Batches'),array('classroom.php','▣','Classrooms'),array('attendance.php','✓','Attendance'),array('exams.php','✎','Tests & Marks'));
} elseif ($role === 'student') {
    $navItems = array(array('index.php','⌂','Dashboard'),array('classroom.php','▣','My Classroom'),array('fees.php','₹','My Fees'),array('exams.php','✎','My Results'));
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#111a3a"><title><?= e($titleText) ?> · SAI Physics</title><link rel="stylesheet" href="assets/app.css"><?php include __DIR__ . '/pwa-head.php'; ?></head><body>
<div class="app-shell">
  <aside class="sidebar" id="sidebar">
    <a class="brand" href="index.php"><span class="brand-mark">SP</span><span><strong>SAI Physics</strong><small>LEARN · PRACTISE · EXCEL</small></span></a>
    <div class="side-caption">WORKSPACE</div>
    <nav class="side-nav"><?php foreach ($navItems as $n): ?><a href="<?= e($n[0]) ?>" class="<?= basename($_SERVER['PHP_SELF']) === $n[0] ? 'active' : '' ?>"><span class="nav-icon"><?= e($n[1]) ?></span><?= e($n[2]) ?></a><?php endforeach; ?></nav>
    <div class="sidebar-bottom"><div class="status-dot"></div><span>Secure learning space</span></div>
  </aside>
  <section class="workspace">
    <header class="topbar"><button class="icon-button menu-toggle" id="menu-toggle" aria-label="Toggle navigation">☰</button><div class="breadcrumb"><span>SAI Physics</span><b>/</b><strong><?= e($titleText) ?></strong></div><?php if ($role === 'super_admin' && $tenantRow && $headerSessions): ?><form class="header-session" method="post" action="sessions.php"><input type="hidden" name="action" value="switch"><?=csrf_field() ?><label for="header-session-select">Session</label><select id="header-session-select" name="session_id" onchange="this.form.submit()"><?php foreach($headerSessions as $hs): ?><option value="<?= (int)$hs['id'] ?>" <?= ((int)$hs['id']===$headerCurrentSessionId?'selected':'') ?>><?=e($hs['name'])?></option><?php endforeach; ?></select></form><?php endif; ?><div class="topbar-search"><form method="get" action="global_search.php"><span>⌕</span><input name="q" aria-label="Global student or teacher ID search" placeholder="Search S-XXXX-YYYY / T-XXXX" autocomplete="off"></form></div><div class="topbar-right"><?php if ($tenantRow): ?><span class="tenant-chip">◆ <?= e($tenantRow['name']) ?></span><?php elseif ($role === 'super_admin'): ?><span class="tenant-chip">◆ Platform control</span><?php endif; ?><div class="user-chip"><span class="avatar"><?= e(strtoupper(substr($me['name'] ?? 'U',0,1))) ?></span><span><b><?= e($me['name'] ?? 'User') ?></b><small><?= e(str_replace('_',' ',ucfirst($role))) ?><?= $myLoginCode ? ' · '.e($myLoginCode) : '' ?></small></span></div><a class="logout-link" href="account.php">Account</a><a class="logout-link" href="logout.php">Sign out</a></div></header>
    <main class="content">
      <?php if ($flashMessage): ?><div class="alert <?= e($flashMessage['type']) ?>" role="status"><?= e($flashMessage['message']) ?></div><?php endif; ?>
