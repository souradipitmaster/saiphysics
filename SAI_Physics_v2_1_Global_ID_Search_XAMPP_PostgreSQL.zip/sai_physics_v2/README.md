# SAI Physics v2.1

A modern, responsive coaching-institute management application built with PHP and PDO. The initial deployment target is XAMPP + MySQL. The same application query layer supports PostgreSQL through a configuration switch and a separate schema.

## Included modules

- Super Admin institute/tenant creation, activation and workspace selection.
- Global exact-ID lookup for student (`S-XXXX-YYYY`) and teacher (`T-XXXX`) profiles, with permission-aware history views.
- Tenant-scoped administrator, teacher and student accounts.
- Academic sessions and session switching.
- Batch creation with an automatically created classroom.
- Many-to-many teacher-to-batch assignments.
- Student admissions, optional student portal accounts, batch transfers, cross-session promotion, graduation/left status, enable/disable and deletion.
- Batch-wise fee generation, student fee ledgers, discounts, waivers, optional/mandatory fine and offline Cash/UPI/Bank payments.
- Payment receipt history and optional Razorpay order creation + signature/capture verification.
- Batch classrooms with embedded YouTube lessons and controlled study-material downloads.
- Attendance marking and student attendance view.
- Tests/exams and marks entry/result view.
- PWA install support with a safe static-asset cache. Private dashboard pages are not cached offline.

## 1. Requirements

- PHP 7.4 or later (PHP 8.1+ recommended for new live deployments).
- Apache with PHP enabled; XAMPP is supported.
- MySQL 5.7+ or MariaDB 10.3+ for the initial setup.
- PHP extensions: `pdo_mysql`, `openssl`, `fileinfo`; `curl` is required only for Razorpay.
- PostgreSQL 12+ with `pdo_pgsql` for the PostgreSQL option.

The PHP runtime used for the source package syntax check did not have `pdo_mysql`, `pdo_pgsql` or `curl` enabled, so database-backed runtime tests and live gateway tests could not be run in this build environment. Enable the relevant extensions in your XAMPP `php.ini`.

## 2. Install on XAMPP (Windows)

1. Extract the ZIP into `C:\xampp\htdocs\`. Confirm that the files are inside `C:\xampp\htdocs\sai_physics_v2\` (so `login.php` is directly inside that folder, not in a nested duplicate folder).
2. Open XAMPP Control Panel and start Apache and MySQL.
3. Open `http://localhost/phpmyadmin`.
4. Create a database named `sai_physics` using `utf8mb4_unicode_ci`.
5. Select `sai_physics` → **Import** → choose `database/mysql/database.sql` → **Go**.
6. Open `config/database.php`. Confirm `DB_DRIVER` is `mysql`, `DB_HOST` is `127.0.0.1`, `DB_PORT` is `3306`, `DB_NAME` is `sai_physics`, `DB_USER` is `root`, and `DB_PASS` matches your MySQL password. Environment variables with the same names override the defaults.
7. For a fresh deployment, generate a unique 64-character key with `php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"` and replace `APP_KEY` in `config/app.php` before first use. Back it up securely. For an upgrade of an existing installation, preserve its existing `APP_KEY` exactly. Do not change it after adding encrypted video IDs; old IDs cannot be decrypted with a different key.
8. Visit `http://localhost/sai_physics_v2/install.php`, create and confirm the Super Admin password, and run the one-time setup. No activation key is required. It creates the demo institute, academic session, demo users, sample batches, classrooms and teacher assignment. The installer locks itself after success using a database setting and a private `storage/install.lock` marker. Run setup before making the site publicly accessible.
9. Visit `http://localhost/sai_physics_v2/login.php` and use the Super Admin email with the password you just created, or use one of the other demo accounts below.

If you extract the project into a folder with a different name, use that folder name in the URL. Asset paths and PWA scope are relative; the application is not hard-coded to `/sai_physics/`.

### Demo accounts

| Role | Email | Initial password |
|---|---|---|
| Super Admin | `super@saiphysics.com` | Password created during installation |
| Admin | `admin@saiphysics.com` | `admin123` |
| Teacher | `teacher@saiphysics.com` | `teacher123` |
| Student | `student@saiphysics.com` | `student123` |

The Super Admin password is created during installation. The Admin, Teacher and Student demo accounts are forced to change their sample passwords at first sign-in. Teachers can sign in using their Teacher ID, and students with a portal account can sign in using their Student ID; Super Admin and Admin use email addresses. The login page does not publicly display demo credentials. Use a unique password of at least 10 characters, including letters and numbers. Remove or disable demo accounts before a real production launch.

## 3. Configuration

### Database

Edit `config/database.php` or set the equivalent environment variables:

- `DB_DRIVER`: `mysql` or `pgsql`
- `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASS`

The application uses PDO prepared statements and a shared `db()` connection helper. Database-generated IDs are abstracted through `db_insert_id()`. Avoid adding vendor-specific SQL (for example, `GROUP_CONCAT`, `INSERT IGNORE`, `IF()` or MySQL-only upserts) to application pages.

### Application secrets

- `APP_KEY`: encryption key for protected YouTube video IDs. Keep a secure backup. Do not rotate after videos are stored unless you first decrypt/re-encrypt those rows.
- `APP_DEBUG`: keep `0` on a public server.

### Razorpay (optional)

Online payments are disabled by default. Offline payments work without gateway credentials. For Razorpay:

1. Test with Razorpay test credentials first.
2. Enable the PHP `curl` extension.
3. Configure `GATEWAY_ENABLED=1`, `RAZORPAY_KEY_ID`, and `RAZORPAY_KEY_SECRET` as server environment variables (do not commit live keys into the ZIP or source control).
4. Use HTTPS and verify the account's capture settings/webhook workflow before accepting real payments.

The checkout creates a Razorpay order on the server, verifies the returned HMAC signature, fetches the payment from Razorpay, checks capture status/order/amount, then records the payment transactionally. A live gateway account and correct credentials are required; this cannot be tested using demo credentials.

## 4. PostgreSQL migration

The application pages use PDO queries intended to run on both database drivers. PostgreSQL has its own schema at `database/postgresql/database.sql`.

1. Take a full MySQL backup and stop writes to the old application during migration.
2. Create an empty PostgreSQL database (UTF-8) and import `database/postgresql/database.sql` into it.
3. Run the migration utility from the command line with source/target environment variables. It requires both PDO drivers and an empty target database:

```bash
MIGRATE_MYSQL_HOST=127.0.0.1 MIGRATE_MYSQL_PORT=3306 MIGRATE_MYSQL_DB=sai_physics MIGRATE_MYSQL_USER=root MIGRATE_MYSQL_PASS=... \
MIGRATE_PGSQL_HOST=127.0.0.1 MIGRATE_PGSQL_PORT=5432 MIGRATE_PGSQL_DB=sai_physics MIGRATE_PGSQL_USER=postgres MIGRATE_PGSQL_PASS=... \
php tools/migrate_mysql_to_postgresql.php
```

On Windows CMD, set each variable using `set NAME=value` before running `php tools\migrate_mysql_to_postgresql.php`. Do not use `--truncate` unless you intentionally want to clear all target tables; the default behavior refuses non-empty tables.
4. Verify record counts and sample users, fees, receipts, attendance and marks in PostgreSQL.
5. Change `DB_DRIVER` to `pgsql`, `DB_PORT` to `5432`, and the PostgreSQL host/user/password in `config/database.php` or environment. Enable `pdo_pgsql` and test the full application before switching DNS/live traffic.

The migration utility copies application rows and resets PostgreSQL identity sequences. It does not migrate MySQL server users, grants, scheduled jobs, uploads stored outside `storage/materials`, or web-server configuration. Copy the `storage/materials` folder and preserve `APP_KEY` during migration.

## 5. Live hosting checklist

- Deploy behind HTTPS; PWA installation on real mobile devices requires HTTPS (except localhost).
- Use a dedicated database user with only the permissions the application needs; do not use MySQL `root` in production.
- Keep `APP_KEY` secret and backed up, remove demo accounts, and set strong passwords. There is no separate installer activation key in v2.1.
- Keep `APP_DEBUG=0`; ensure Apache honors the included `.htaccess` rules and directory listing is disabled.
- Make `storage/materials` writable by the PHP process but not directly web-readable. Downloads are streamed through `download.php` after access checks.
- Back up the database and `storage/materials` regularly.
- Use a supported, maintained PHP version; old Windows Server/XAMPP stacks should not be exposed directly to the public internet.

## 6. Video privacy and browser limits

The application stores the YouTube video ID using AES-256-GCM authenticated encryption and decrypts it only for an authorized classroom page. The ID must still be delivered to the browser player, and YouTube controls the underlying stream. Use YouTube's appropriate embed/privacy settings. Watermarking and page-visibility pause are deterrents and audit aids, not DRM. A website cannot guarantee blocking OS-level screenshots or screen recording.

## 7. Performance and maintenance

- Database indexes cover tenant/session lists, batch membership, fee ledgers, payments and classroom lookups.
- Lists are bounded to 500/1,000 rows in the main pages to avoid unbounded result rendering.
- Prepared statements are used for data writes and user-controlled filters.
- Dashboard queries use aggregate counts/sums rather than loading full detail rows.
- Dynamic user pages are not cached by the service worker; only static assets and the offline page are cached.

For production scale, add a reverse proxy/PHP OPcache, periodic DB backups, monitoring, and a dedicated mail/SMS service as required.



## v2.1 Global ID Search and IDs

Every newly admitted student receives a permanent ID in the format `S-0001-2026`; every newly created teacher receives a `T-0001` ID. Teachers can use the Teacher ID and students with an enabled portal account can use the Student ID as the login identifier (instead of email). IDs are generated from platform-wide sequences, are not case-sensitive at search time, and are shown in the Students and Teachers directories. A promotion created after v2.1 reuses the same student registry ID across academic sessions.

Use the global search field in the header or **Global ID Search** in the sidebar. Search is an exact ID lookup, not a broad name search. Super Admin can search across all institutes; Admin can search the currently selected institute; Teachers can view their own profile and students linked to their assigned batches; Students can view only their own profile.

Student details include identity/contact information, all available session enrolments, batch, status, fees payable, paid totals, attendance-record count and assessment-record count. Teacher details include identity, account status and assigned batches/sessions.

### Upgrading an existing v2.0 database

Back up the database first, then run exactly one matching script:
- MySQL/MariaDB: `database/mysql/upgrade_v21_global_search.sql`
- PostgreSQL: `database/postgresql/upgrade_v21_global_search.sql`

Run the script once, then deploy the v2.1 PHP/assets files. The upgrade backfills IDs for existing student-session records and teacher accounts. Since v2.0 did not have a permanent student registry, existing duplicate session records for one learner may receive separate IDs; newly created promotions after the upgrade retain the same ID. Manually reconcile historical duplicates that represent the same learner, if necessary.

### Session selector

The Super Admin sees the active-session selector in the topbar after opening an institute. Tenant Admins can create sessions but cannot switch the active session by default. A configurable permission matrix to delegate this capability to selected staff is not part of this incremental release yet.
