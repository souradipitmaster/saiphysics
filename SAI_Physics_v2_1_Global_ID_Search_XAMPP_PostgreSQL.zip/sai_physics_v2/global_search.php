<?php
require_once __DIR__ . '/app/bootstrap.php';
require_login();
$page_title = 'Global ID Search';
$qInput = strtoupper(trim((string)($_GET['q'] ?? '')));
$searchError = '';
$foundType = '';
$foundId = 0;
$studentCode = '';
$teacherCode = '';
$summary = array();
if ($qInput !== '') {
    if (preg_match('/^S-[0-9]{4,}-20[0-9]{2}$/', $qInput)) {
        $q = db()->prepare('SELECT id,tenant_id,student_code FROM student_registry WHERE student_code = ?');
        $q->execute(array($qInput)); $row = $q->fetch();
        if ($row) {
            $allowed = false;
            if (current_role() === 'super_admin') $allowed = true;
            elseif (current_role() === 'admin') $allowed = ((int)$row['tenant_id'] === current_tenant());
            elseif (current_role() === 'teacher') { $p=db()->prepare('SELECT COUNT(*) FROM students s JOIN batch_teachers bt ON bt.batch_id=s.batch_id JOIN users tu ON tu.id=bt.teacher_id WHERE s.registry_id=? AND s.tenant_id=? AND tu.id=?'); $p->execute(array((int)$row['id'],current_tenant(),(int)current_user()['id'])); $allowed=(int)$p->fetchColumn()>0; }
            elseif (current_role() === 'student') { $p=db()->prepare('SELECT COUNT(*) FROM students WHERE registry_id=? AND tenant_id=? AND user_id=?'); $p->execute(array((int)$row['id'],(int)current_user()['tenant_id'],(int)current_user()['id'])); $allowed=(int)$p->fetchColumn()>0; }
            if ($allowed) {
                $foundType='student'; $foundId=(int)$row['id']; $studentCode=$row['student_code'];
                $sp=db()->prepare('SELECT s.name,s.email,s.phone,s.guardian_name,s.guardian_phone,s.admission_no,s.status,s.is_active,b.name AS batch_name,se.name AS session_name,t.name AS tenant_name FROM students s JOIN sessions se ON se.id=s.session_id JOIN tenants t ON t.id=s.tenant_id LEFT JOIN batches b ON b.id=s.batch_id WHERE s.registry_id=? ORDER BY se.start_date DESC,s.created_at DESC LIMIT 1');
                $sp->execute(array($foundId)); $summary=$sp->fetch() ?: array();
            }
        }
    } elseif (preg_match('/^T-[0-9]{4,}$/', $qInput)) {
        $q = db()->prepare("SELECT u.id,u.tenant_id,u.name,u.email,u.phone,u.teacher_code,u.is_active,t.name AS tenant_name,(SELECT COUNT(*) FROM batch_teachers bt WHERE bt.teacher_id=u.id) AS batch_count FROM users u LEFT JOIN tenants t ON t.id=u.tenant_id WHERE u.teacher_code = ? AND u.role = 'teacher'");
        $q->execute(array($qInput)); $row = $q->fetch();
        if ($row) {
            $allowed = current_role() === 'super_admin' || (current_role() === 'admin' && (int)$row['tenant_id'] === current_tenant()) || (current_role() === 'teacher' && (int)$row['id'] === (int)current_user()['id']);
            if ($allowed) { $foundType='teacher'; $foundId=(int)$row['id']; $teacherCode=$row['teacher_code']; $summary=$row; }
        }
    } else { $searchError = 'Enter a valid ID, such as S-0001-2026 or T-0001. IDs are not case-sensitive.'; }
    if ($searchError === '' && !$foundType) $searchError = 'No matching record was found, or you do not have permission to view it.';
}
require __DIR__ . '/includes/header.php';
?>
<div class="page-heading"><div><div class="eyebrow">PLATFORM DIRECTORY</div><h1>Global ID Search</h1><p>Find a student or teacher using their permanent ID. Search covers previous academic sessions as well.</p></div><span class="badge info">Case-insensitive</span></div>
<section class="panel id-search-panel"><form method="get" class="id-search-form"><div class="field" style="flex:1;margin:0"><label for="global-id">Student ID or Teacher ID</label><input id="global-id" name="q" value="<?=e($qInput)?>" placeholder="S-0001-2026 or T-0001" autocomplete="off" required></div><button class="btn" type="submit">⌕ Search ID</button></form><p class="help-text">Student format: <strong>S-XXXX-YYYY</strong> · Teacher format: <strong>T-XXXX</strong>. Administrators can search within their institute; Super Admin can search across institutes. Teachers and students only see records they are authorized to access.</p></section>
<?php if($searchError):?><div class="alert <?= $qInput && !$foundType && strpos($searchError,'Enter a valid')===0 ? 'info':'error' ?>"><?=e($searchError)?></div><?php endif;?>
<?php if($foundType):?><section class="panel"><div class="person-result-head"><div><div class="eyebrow">MATCH FOUND</div><h2><?= $foundType==='student' ? 'Student profile' : 'Teacher profile' ?></h2><p class="panel-sub"><?=e($summary['tenant_name']??'')?> · <?=e($foundType==='student'?'Student':'Teacher')?> identity</p></div><span class="identity-pill"><?=e($foundType==='student'?$studentCode:$teacherCode)?></span></div><div class="profile-grid" style="margin:18px 0 20px"><?php if($foundType==='student'):?><div><small>Student name</small><strong><?=e($summary['name']??'—')?></strong></div><div><small>Current / latest batch</small><strong><?=e($summary['batch_name']??'Unassigned')?></strong></div><div><small>Academic session</small><strong><?=e($summary['session_name']??'—')?></strong></div><div><small>Phone</small><strong><?=e($summary['phone']??'—')?></strong></div><div><small>Guardian</small><strong><?=e($summary['guardian_name']??'—')?></strong></div><div><small>Admission number</small><strong><?=e($summary['admission_no']??'—')?></strong></div><div><small>Status</small><strong><?=e($summary['status']??'—')?><?=((int)($summary['is_active']??0)===1?'':' · disabled')?></strong></div><?php else:?><div><small>Teacher name</small><strong><?=e($summary['name']??'—')?></strong></div><div><small>Email</small><strong><?=e($summary['email']??'—')?></strong></div><div><small>Phone</small><strong><?=e($summary['phone']??'—')?></strong></div><div><small>Assigned batches</small><strong><?=number_format((int)($summary['batch_count']??0))?></strong></div><div><small>Account status</small><strong><?=((int)($summary['is_active']??0)===1?'Active':'Disabled')?></strong></div><?php endif;?></div><a class="btn" href="person.php?type=<?=e($foundType)?>&amp;<?= $foundType==='student' ? 'rid='.(int)$foundId : 'id='.(int)$foundId ?>">View complete history →</a></section><?php endif;?>
<?php require __DIR__ . '/includes/footer.php'; ?>
