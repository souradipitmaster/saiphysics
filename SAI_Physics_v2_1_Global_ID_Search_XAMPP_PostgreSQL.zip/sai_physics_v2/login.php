<?php
require_once __DIR__ . '/app/bootstrap.php';
if (current_user()) redirect(current_user()['must_change_password'] ? 'account.php' : 'index.php');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim((string)($_POST['identifier'] ?? '')); $password = (string)($_POST['password'] ?? '');
    if ($identifier === '' || $password === '') $error = 'Enter your email or institute ID and password.';
    else {
        try {
            $q = db()->prepare("SELECT u.*, t.is_active AS tenant_active FROM users u LEFT JOIN tenants t ON t.id=u.tenant_id WHERE LOWER(u.email)=LOWER(?) OR (u.role='teacher' AND UPPER(u.teacher_code)=UPPER(?)) OR (u.role='student' AND EXISTS (SELECT 1 FROM students s JOIN student_registry sr ON sr.id=s.registry_id WHERE s.user_id=u.id AND UPPER(sr.student_code)=UPPER(?))) ORDER BY u.id LIMIT 1");
            $q->execute(array($identifier,$identifier,$identifier)); $user = $q->fetch();
            if ($user && (int)$user['is_active'] === 1 && ($user['role'] === 'super_admin' || (int)$user['tenant_active'] === 1) && password_verify($password,$user['password_hash'])) {
                session_regenerate_id(true);
                unset($user['password_hash'], $user['tenant_active']); $_SESSION['user'] = $user;
                if ($user['role'] !== 'super_admin') {
                    $q = db()->prepare('SELECT id FROM sessions WHERE tenant_id=? ORDER BY is_current DESC,start_date DESC,id DESC LIMIT 1'); $q->execute(array($user['tenant_id']));
                    $_SESSION['active_session_id'] = (int)$q->fetchColumn();
                }
                db()->prepare('UPDATE users SET last_login_at=CURRENT_TIMESTAMP WHERE id=?')->execute(array($user['id']));
                redirect(!empty($user['must_change_password']) ? 'account.php' : 'index.php');
            }
            $error = 'The login ID/email or password is incorrect, or the account is inactive.';
        } catch (Throwable $ex) { log_error($ex->getMessage()); $error = 'Unable to connect to the application database. Check config/database.php.'; }
    }
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#111a3a"><title>Sign in · SAI Physics</title><link rel="stylesheet" href="assets/app.css"><?php include __DIR__ . '/includes/pwa-head.php'; ?></head><body class="login-page"><div class="login-layout"><section class="login-art"><div><a class="brand" href="login.php" style="padding:0"><span class="brand-mark">SP</span><span><strong>SAI Physics</strong><small>LEARN · PRACTISE · EXCEL</small></span></a><h1>Make every<br>lesson count.</h1><p>Your focused learning space for batches, classrooms, fees and academic progress.</p></div><div class="login-features"><span>✦ Smart classrooms</span><span>▤ Batch management</span><span>✓ Learning progress</span></div></section><section class="login-form-wrap"><div class="eyebrow">WELCOME BACK</div><h2>Sign in to continue</h2><p>Sign in using your institute ID and password. Admin accounts can use their email address.</p><?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?><form method="post" autocomplete="on"><div class="field"><label>Email / Student ID / Teacher ID</label><input type="text" name="identifier" placeholder="email, S-0001-2026 or T-0001" required autocomplete="username" value="<?= e($_POST['identifier'] ?? '') ?>"></div><div class="field"><label>Password</label><input type="password" name="password" placeholder="Enter your password" required autocomplete="current-password"></div><?= csrf_field() ?><button class="btn" type="submit">Sign in <span>→</span></button></form><div class="demo-logins"><b>New installation?</b><br>Import the database schema, then run the one-time installer. Ask your institute administrator for your login credentials.</div></section></div><script src="assets/install.js" defer></script></body></html>
