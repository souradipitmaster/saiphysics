<?php
require_once __DIR__ . '/app/bootstrap.php'; require_login();
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $old=(string)($_POST['current_password']??''); $new=(string)($_POST['new_password']??''); $confirm=(string)($_POST['confirm_password']??'');
    $q=db()->prepare('SELECT password_hash FROM users WHERE id=?'); $q->execute(array(current_user()['id'])); $hash=$q->fetchColumn();
    if (!password_verify($old,$hash)) $error='Current password is not correct.';
    elseif (strlen($new)<10 || !preg_match('/[A-Za-z]/',$new) || !preg_match('/[0-9]/',$new)) $error='Use at least 10 characters with letters and numbers.';
    elseif ($new!==$confirm) $error='New password and confirmation do not match.';
    else { db()->prepare('UPDATE users SET password_hash=?,must_change_password=0 WHERE id=?')->execute(array(password_hash($new,PASSWORD_DEFAULT),current_user()['id'])); $_SESSION['user']['must_change_password']=0; flash('success','Password changed successfully.'); redirect('index.php'); }
}
$page_title='My Account'; require 'includes/header.php';
?><div class="page-heading"><div><div class="eyebrow">ACCOUNT SECURITY</div><h1>Change password</h1><p>Keep your account protected with a unique password.</p></div></div><?php if($error): ?><div class="alert error"><?=e($error)?></div><?php endif; ?><section class="panel" style="max-width:620px"><form method="post"><div class="field"><label>Current password</label><input type="password" name="current_password" required autocomplete="current-password"></div><div class="field"><label>New password</label><input type="password" name="new_password" minlength="10" required autocomplete="new-password"><span class="help-text">At least 10 characters, including letters and numbers.</span></div><div class="field"><label>Confirm new password</label><input type="password" name="confirm_password" minlength="10" required autocomplete="new-password"></div><?=csrf_field()?><button class="btn" type="submit">Update password</button></form></section><?php require 'includes/footer.php'; ?>
