<?php
/** SAI Physics v2.1 application configuration. Change secrets before live deployment. */
date_default_timezone_set('Asia/Kolkata');
if (!defined('APP_NAME')) define('APP_NAME', 'SAI Physics');
if (!defined('APP_ENV')) define('APP_ENV', getenv('APP_ENV') ?: 'production');
if (!defined('APP_DEBUG')) define('APP_DEBUG', (getenv('APP_DEBUG') ?: '0') === '1');
if (!defined('APP_KEY')) define('APP_KEY', getenv('APP_KEY') ?: '73e1151888b8e057be2ac8de06841e370ca22b4d10e94fb62b5f136a134b0e82');
if (!defined('APP_URL')) define('APP_URL', rtrim(getenv('APP_URL') ?: '', '/'));
if (!defined('MAX_UPLOAD_BYTES')) define('MAX_UPLOAD_BYTES', 12 * 1024 * 1024);
if (APP_DEBUG) { ini_set('display_errors', '1'); error_reporting(E_ALL); }
else { ini_set('display_errors', '0'); error_reporting(E_ALL); }
