<?php
/** Database driver can be switched from mysql to pgsql without changing app queries. */
if (!defined('DB_DRIVER')) define('DB_DRIVER', strtolower(getenv('DB_DRIVER') ?: 'mysql'));
if (!defined('DB_HOST')) define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
if (!defined('DB_PORT')) define('DB_PORT', getenv('DB_PORT') ?: (DB_DRIVER === 'pgsql' ? '5432' : '3306'));
if (!defined('DB_NAME')) define('DB_NAME', getenv('DB_NAME') ?: 'sai_physics');
if (!defined('DB_USER')) define('DB_USER', getenv('DB_USER') ?: 'root');
if (!defined('DB_PASS')) define('DB_PASS', getenv('DB_PASS') ?: '');
function db()
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    if (!in_array(DB_DRIVER, array('mysql', 'pgsql'), true)) throw new RuntimeException('Unsupported DB_DRIVER. Use mysql or pgsql.');
    $dsn = DB_DRIVER === 'pgsql'
        ? 'pgsql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME
        : 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASS, array(
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ));
    if (DB_DRIVER === 'mysql') $pdo->exec("SET NAMES utf8mb4");
    return $pdo;
}
function db_insert_id($sql, $params = array())
{
    $pdo = db();
    if (DB_DRIVER === 'pgsql') {
        $stmt = $pdo->prepare(rtrim($sql, " ;\n\t") . ' RETURNING id');
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (int)$pdo->lastInsertId();
}
