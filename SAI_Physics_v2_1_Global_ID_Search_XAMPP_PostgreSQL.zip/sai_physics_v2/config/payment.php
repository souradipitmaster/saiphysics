<?php
/** Set these environment variables only after enabling a live gateway account. */
if (!defined('GATEWAY_ENABLED')) define('GATEWAY_ENABLED', (getenv('GATEWAY_ENABLED') ?: '0') === '1');
if (!defined('RAZORPAY_KEY_ID')) define('RAZORPAY_KEY_ID', getenv('RAZORPAY_KEY_ID') ?: '');
if (!defined('RAZORPAY_KEY_SECRET')) define('RAZORPAY_KEY_SECRET', getenv('RAZORPAY_KEY_SECRET') ?: '');
if (!defined('CURRENCY')) define('CURRENCY', 'INR');
