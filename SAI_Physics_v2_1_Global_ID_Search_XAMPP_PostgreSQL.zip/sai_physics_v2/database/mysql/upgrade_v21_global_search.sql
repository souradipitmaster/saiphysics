-- SAI Physics v2.1 identity and global-search migration (MySQL 5.7+/MariaDB 10.3+)
-- Run once against the existing sai_physics database before deploying the v2.1 PHP files.
ALTER TABLE users ADD COLUMN teacher_code VARCHAR(32) NULL;
CREATE UNIQUE INDEX uq_users_teacher_code ON users(teacher_code);
UPDATE users SET teacher_code=CONCAT('T-',LPAD(id,4,'0')) WHERE role='teacher' AND (teacher_code IS NULL OR teacher_code='');

CREATE TABLE student_registry (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  tenant_id BIGINT UNSIGNED NOT NULL,
  student_code VARCHAR(40) NULL UNIQUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_student_registry_tenant (tenant_id),
  CONSTRAINT fk_student_registry_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE students ADD COLUMN registry_id BIGINT UNSIGNED NULL;
INSERT INTO student_registry (id,tenant_id,student_code,created_at)
SELECT s.id,s.tenant_id,CONCAT('S-',LPAD(s.id,4,'0'),'-',COALESCE(YEAR(se.start_date),YEAR(CURRENT_DATE))),s.created_at
FROM students s LEFT JOIN sessions se ON se.id=s.session_id;
UPDATE students SET registry_id=id;
CREATE INDEX idx_students_registry ON students(registry_id);
ALTER TABLE students ADD CONSTRAINT fk_students_registry FOREIGN KEY (registry_id) REFERENCES student_registry(id) ON DELETE SET NULL;
SET @next_registry_id=(SELECT COALESCE(MAX(id),0)+1 FROM student_registry);
SET @registry_sql=CONCAT('ALTER TABLE student_registry AUTO_INCREMENT=',@next_registry_id);
PREPARE registry_stmt FROM @registry_sql; EXECUTE registry_stmt; DEALLOCATE PREPARE registry_stmt;
