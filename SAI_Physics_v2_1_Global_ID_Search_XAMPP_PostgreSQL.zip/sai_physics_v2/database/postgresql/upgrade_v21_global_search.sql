-- SAI Physics v2.1 identity and global-search migration (PostgreSQL 12+)
-- Run once against the existing sai_physics database before deploying the v2.1 PHP files.
ALTER TABLE users ADD COLUMN teacher_code VARCHAR(32);
CREATE UNIQUE INDEX uq_users_teacher_code ON users(teacher_code);
UPDATE users SET teacher_code='T-' || LPAD(id::text,4,'0') WHERE role='teacher' AND (teacher_code IS NULL OR teacher_code='');

CREATE TABLE student_registry (
 id BIGSERIAL PRIMARY KEY,
 tenant_id BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
 student_code VARCHAR(40) UNIQUE,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_student_registry_tenant ON student_registry(tenant_id);
ALTER TABLE students ADD COLUMN registry_id BIGINT REFERENCES student_registry(id) ON DELETE SET NULL;
INSERT INTO student_registry (id,tenant_id,student_code,created_at)
SELECT s.id,s.tenant_id,'S-' || LPAD(s.id::text,4,'0') || '-' || COALESCE(EXTRACT(YEAR FROM se.start_date)::int,EXTRACT(YEAR FROM CURRENT_DATE)::int)::text,s.created_at
FROM students s LEFT JOIN sessions se ON se.id=s.session_id;
UPDATE students s SET registry_id=s.id;
CREATE INDEX idx_students_registry ON students(registry_id);
SELECT setval(pg_get_serial_sequence('student_registry','id'), COALESCE(MAX(id),1), MAX(id) IS NOT NULL) FROM student_registry;
