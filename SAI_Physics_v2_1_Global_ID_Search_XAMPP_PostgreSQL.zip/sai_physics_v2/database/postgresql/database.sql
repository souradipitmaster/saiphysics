-- SAI Physics v2.0 - PostgreSQL 12+ schema
-- Create database sai_physics with UTF8 encoding, then run this file in that database.

CREATE TABLE IF NOT EXISTS tenants (
 id BIGSERIAL PRIMARY KEY, name VARCHAR(150) NOT NULL, slug VARCHAR(100) NOT NULL UNIQUE,
 email VARCHAR(190) NOT NULL, phone VARCHAR(30) NOT NULL, address TEXT, logo_path VARCHAR(255),
 is_active SMALLINT NOT NULL DEFAULT 1, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sessions (
 id BIGSERIAL PRIMARY KEY, tenant_id BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
 name VARCHAR(50) NOT NULL, start_date DATE, end_date DATE, is_current SMALLINT NOT NULL DEFAULT 0,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(tenant_id,name)
);
CREATE INDEX IF NOT EXISTS idx_sessions_tenant_current ON sessions(tenant_id,is_current);
CREATE TABLE IF NOT EXISTS users (
 id BIGSERIAL PRIMARY KEY, tenant_id BIGINT REFERENCES tenants(id) ON DELETE CASCADE,
 name VARCHAR(150) NOT NULL, email VARCHAR(190) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL,
 role VARCHAR(20) NOT NULL, teacher_code VARCHAR(32) UNIQUE, phone VARCHAR(30), is_active SMALLINT NOT NULL DEFAULT 1,
 must_change_password SMALLINT NOT NULL DEFAULT 0, last_login_at TIMESTAMP,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_users_tenant_role ON users(tenant_id,role);
CREATE TABLE IF NOT EXISTS student_registry (
 id BIGSERIAL PRIMARY KEY, tenant_id BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
 student_code VARCHAR(40) UNIQUE, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_student_registry_tenant ON student_registry(tenant_id);
CREATE TABLE IF NOT EXISTS batches (
 id BIGSERIAL PRIMARY KEY, tenant_id BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
 session_id BIGINT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE, name VARCHAR(150) NOT NULL,
 class_name VARCHAR(80), subject VARCHAR(100) NOT NULL DEFAULT 'Physics', timing VARCHAR(100), room VARCHAR(100),
 max_students INTEGER NOT NULL DEFAULT 50, fees_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
 is_active SMALLINT NOT NULL DEFAULT 1, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_batches_tenant_session ON batches(tenant_id,session_id);
CREATE TABLE IF NOT EXISTS batch_teachers (
 id BIGSERIAL PRIMARY KEY, batch_id BIGINT NOT NULL REFERENCES batches(id) ON DELETE CASCADE,
 teacher_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 assigned_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
 assigned_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(batch_id,teacher_id)
);
CREATE INDEX IF NOT EXISTS idx_bt_teacher ON batch_teachers(teacher_id);
CREATE TABLE IF NOT EXISTS students (
 id BIGSERIAL PRIMARY KEY, tenant_id BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
 session_id BIGINT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
 batch_id BIGINT REFERENCES batches(id) ON DELETE SET NULL, user_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
 registry_id BIGINT REFERENCES student_registry(id) ON DELETE SET NULL,
 name VARCHAR(150) NOT NULL, email VARCHAR(190), phone VARCHAR(30), guardian_name VARCHAR(150), guardian_phone VARCHAR(30),
 admission_no VARCHAR(60), address TEXT, status VARCHAR(20) NOT NULL DEFAULT 'active', is_active SMALLINT NOT NULL DEFAULT 1,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(tenant_id,session_id,admission_no),
 UNIQUE(tenant_id,session_id,user_id)
);
CREATE INDEX IF NOT EXISTS idx_students_tenant_session ON students(tenant_id,session_id);
CREATE INDEX IF NOT EXISTS idx_students_batch ON students(batch_id);
CREATE INDEX IF NOT EXISTS idx_students_user ON students(user_id);
CREATE INDEX IF NOT EXISTS idx_students_registry ON students(registry_id);
CREATE TABLE IF NOT EXISTS batch_transfers (
 id BIGSERIAL PRIMARY KEY, tenant_id BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
 session_id BIGINT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
 student_id BIGINT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
 from_batch_id BIGINT REFERENCES batches(id) ON DELETE SET NULL,
 to_batch_id BIGINT NOT NULL REFERENCES batches(id) ON DELETE CASCADE, reason TEXT,
 transferred_by BIGINT REFERENCES users(id) ON DELETE SET NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_transfers_student ON batch_transfers(student_id,created_at);
CREATE TABLE IF NOT EXISTS fees (
 id BIGSERIAL PRIMARY KEY, tenant_id BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
 session_id BIGINT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
 batch_id BIGINT NOT NULL REFERENCES batches(id) ON DELETE CASCADE, title VARCHAR(150) NOT NULL,
 amount NUMERIC(12,2) NOT NULL, due_date DATE, fine_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
 fine_after_days INTEGER NOT NULL DEFAULT 0, is_optional_fine SMALLINT NOT NULL DEFAULT 1,
 created_by BIGINT REFERENCES users(id) ON DELETE SET NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_fees_tenant_session ON fees(tenant_id,session_id);
CREATE TABLE IF NOT EXISTS student_fees (
 id BIGSERIAL PRIMARY KEY, fee_id BIGINT NOT NULL REFERENCES fees(id) ON DELETE CASCADE,
 student_id BIGINT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
 tenant_id BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
 session_id BIGINT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
 original_amount NUMERIC(12,2) NOT NULL, discount NUMERIC(12,2) NOT NULL DEFAULT 0,
 waived NUMERIC(12,2) NOT NULL DEFAULT 0, fine NUMERIC(12,2) NOT NULL DEFAULT 0,
 payable NUMERIC(12,2) NOT NULL, paid NUMERIC(12,2) NOT NULL DEFAULT 0,
 status VARCHAR(20) NOT NULL DEFAULT 'pending', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(fee_id,student_id)
);
CREATE INDEX IF NOT EXISTS idx_student_fees ON student_fees(tenant_id,session_id,status);
CREATE TABLE IF NOT EXISTS payments (
 id BIGSERIAL PRIMARY KEY, student_fee_id BIGINT NOT NULL REFERENCES student_fees(id) ON DELETE CASCADE,
 student_id BIGINT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
 tenant_id BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
 session_id BIGINT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
 amount NUMERIC(12,2) NOT NULL, method VARCHAR(24) NOT NULL, gateway VARCHAR(40), gateway_txn_id VARCHAR(150),
 receipt_no VARCHAR(70) NOT NULL UNIQUE, remarks TEXT,
 received_by BIGINT REFERENCES users(id) ON DELETE SET NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_payments_tenant_session ON payments(tenant_id,session_id);
CREATE INDEX IF NOT EXISTS idx_payments_fee ON payments(student_fee_id);
CREATE TABLE IF NOT EXISTS payment_orders (
 id BIGSERIAL PRIMARY KEY, tenant_id BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
 session_id BIGINT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
 student_fee_id BIGINT NOT NULL REFERENCES student_fees(id) ON DELETE CASCADE,
 user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 gateway_order_id VARCHAR(120) NOT NULL UNIQUE, amount NUMERIC(12,2) NOT NULL,
 currency VARCHAR(8) NOT NULL DEFAULT 'INR', status VARCHAR(20) NOT NULL DEFAULT 'created',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_payment_orders_fee ON payment_orders(student_fee_id);
CREATE TABLE IF NOT EXISTS classrooms (
 id BIGSERIAL PRIMARY KEY, batch_id BIGINT NOT NULL UNIQUE REFERENCES batches(id) ON DELETE CASCADE,
 tenant_id BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
 session_id BIGINT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
 title VARCHAR(200) NOT NULL, description TEXT,
 created_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_classrooms_tenant_session ON classrooms(tenant_id,session_id);
CREATE TABLE IF NOT EXISTS classroom_videos (
 id BIGSERIAL PRIMARY KEY, classroom_id BIGINT NOT NULL REFERENCES classrooms(id) ON DELETE CASCADE,
 title VARCHAR(200) NOT NULL, youtube_video_id_encrypted TEXT NOT NULL, duration VARCHAR(30),
 is_private SMALLINT NOT NULL DEFAULT 1, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_videos_classroom ON classroom_videos(classroom_id);
CREATE TABLE IF NOT EXISTS classroom_materials (
 id BIGSERIAL PRIMARY KEY, classroom_id BIGINT NOT NULL REFERENCES classrooms(id) ON DELETE CASCADE,
 title VARCHAR(200) NOT NULL, stored_name VARCHAR(255) NOT NULL, original_name VARCHAR(255) NOT NULL,
 mime_type VARCHAR(100) NOT NULL, file_size BIGINT NOT NULL,
 uploaded_by BIGINT REFERENCES users(id) ON DELETE SET NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_materials_classroom ON classroom_materials(classroom_id);
CREATE TABLE IF NOT EXISTS attendance (
 id BIGSERIAL PRIMARY KEY, batch_id BIGINT NOT NULL REFERENCES batches(id) ON DELETE CASCADE,
 student_id BIGINT NOT NULL REFERENCES students(id) ON DELETE CASCADE, date DATE NOT NULL,
 status VARCHAR(12) NOT NULL DEFAULT 'present', marked_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(batch_id,student_id,date)
);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(date,batch_id);
CREATE TABLE IF NOT EXISTS exams (
 id BIGSERIAL PRIMARY KEY, tenant_id BIGINT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
 session_id BIGINT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
 batch_id BIGINT NOT NULL REFERENCES batches(id) ON DELETE CASCADE,
 title VARCHAR(180) NOT NULL, exam_date DATE, max_marks NUMERIC(8,2) NOT NULL,
 created_by BIGINT REFERENCES users(id) ON DELETE SET NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_exams_batch ON exams(tenant_id,session_id,batch_id);
CREATE TABLE IF NOT EXISTS exam_marks (
 id BIGSERIAL PRIMARY KEY, exam_id BIGINT NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
 student_id BIGINT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
 marks_obtained NUMERIC(8,2) NOT NULL, remarks VARCHAR(255),
 entered_by BIGINT REFERENCES users(id) ON DELETE SET NULL, UNIQUE(exam_id,student_id)
);
CREATE TABLE IF NOT EXISTS system_settings (
 setting_key VARCHAR(100) PRIMARY KEY, setting_value TEXT, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
