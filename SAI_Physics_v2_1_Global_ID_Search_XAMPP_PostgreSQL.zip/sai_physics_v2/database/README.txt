SAI Physics v2.1 database files

Fresh installation:
- MySQL/MariaDB: import mysql/database.sql
- PostgreSQL: import postgresql/database.sql

Upgrade an existing v2.0 database (back up first; choose only one):
- MySQL/MariaDB: run mysql/upgrade_v21_global_search.sql
- PostgreSQL: run postgresql/upgrade_v21_global_search.sql

Do not run an upgrade script on a fresh v2.1 database; its schema already includes these columns and tables.
