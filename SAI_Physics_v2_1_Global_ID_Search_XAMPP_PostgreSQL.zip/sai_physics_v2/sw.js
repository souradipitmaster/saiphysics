'use strict';
const CACHE='sai-physics-static-v2';
const scopeURL=new URL(self.registration.scope);
const offlineURL=new URL('offline.html',scopeURL).toString();
const STATIC=['offline.html','assets/app.css','assets/app.js','assets/install.js','assets/icons/icon-192.png','assets/icons/icon-512.png'];
self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(STATIC.map(p=>new URL(p,scopeURL).toString()))).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch',event=>{
  const req=event.request;if(req.method!=='GET')return;
  const url=new URL(req.url);if(url.origin!==self.location.origin)return;
  if(req.mode==='navigate'){
    event.respondWith(fetch(req).catch(()=>caches.match(offlineURL)));
    return;
  }
  if(STATIC.some(p=>new URL(p,scopeURL).pathname===url.pathname)){
    event.respondWith(caches.match(req).then(hit=>hit||fetch(req).then(response=>{if(response.ok){const copy=response.clone();caches.open(CACHE).then(c=>c.put(req,copy));}return response;})));
  }
});
