# SAI Physics v2.0 · PWA installation

SAI Physics can be installed as a Progressive Web App without publishing it to the Play Store.

- Android Chrome: open the HTTPS site, then use the app's **Install app** banner or Chrome menu → Install app.
- iPhone/iPad: open the site in Safari → Share → Add to Home Screen.
- Desktop Chrome/Edge: use the browser's install icon/menu when it is offered.

A real public site must use HTTPS. `localhost` is treated as a secure development origin by modern browsers; a private LAN IP over plain HTTP is not enough for installability.

The service worker caches only static CSS/JavaScript/icons and the offline page. It intentionally does not cache authenticated dashboards, student records, fee details, payment responses, or private classroom content. Offline mode therefore provides an offline notice, not offline access to protected student data.

If the application is installed under a subfolder (for example `/sai_physics_v2/`), the manifest and service-worker URLs are relative to that folder.
