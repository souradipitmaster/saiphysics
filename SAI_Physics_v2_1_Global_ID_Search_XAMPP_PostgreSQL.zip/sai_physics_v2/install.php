<?php
require_once __DIR__ . '/app/bootstrap.php';
$done = is_file(__DIR__ . '/storage/install.lock'); $error = '';
if (!$done) {
    try {
        $q = db()->prepare("SELECT setting_value FROM system_settings WHERE setting_key='setup_complete'");
        $q->execute(); $done = $q->fetchColumn() === '1';
        if ($done) { @file_put_contents(__DIR__ . '/storage/install.lock', 'installed ' . date('c') . PHP_EOL, LOCK_EX); }
    } catch (Throwable $ex) { $error = 'Database tables were not found. Import database/mysql/database.sql first and check config/database.php.'; }
}
if (!$done && $_SERVER['REQUEST_METHOD'] === 'POST' && !$error) {
    $superPassword = (string)($_POST['super_password'] ?? '');
    $confirmPassword = (string)($_POST['confirm_password'] ?? '');
    if (strlen($superPassword) < 10) $error = 'Super Admin password must contain at least 10 characters.';
    elseif (!hash_equals($superPassword, $confirmPassword)) $error = 'The two password fields do not match.';
    if (!$error) {
        try {
            $pdo = db(); $pdo->beginTransaction();
        } catch (Throwable $ex) { if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack(); $error = 'Setup failed. Check database schema and error log.'; log_error($ex->getMessage()); }
        if (!$error) {
            try {
                $q = $pdo->prepare('SELECT id FROM tenants WHERE slug=?'); $q->execute(array('sai-physics'));
                $tenantId = (int)$q->fetchColumn();
                if (!$tenantId) $tenantId = db_insert_id('INSERT INTO tenants (name,slug,email,phone,is_active) VALUES (?,?,?,?,1)', array('SAI Physics Classes','sai-physics','admin@saiphysics.com','0000000000'));
                $sessionId = 0;
                $q = $pdo->prepare('SELECT id FROM sessions WHERE tenant_id=? AND name=?'); $q->execute(array($tenantId,'2026-27'));
                $sessionId = (int)$q->fetchColumn();
                if (!$sessionId) $sessionId = db_insert_id('INSERT INTO sessions (tenant_id,name,start_date,end_date,is_current) VALUES (?,?,?,?,1)', array($tenantId,'2026-27','2026-04-01','2027-03-31'));
                $pdo->prepare('UPDATE sessions SET is_current=0 WHERE tenant_id=?')->execute(array($tenantId));
                $pdo->prepare('UPDATE sessions SET is_current=1 WHERE id=?')->execute(array($sessionId));
                $accounts = array(
                    array('Super Admin','super@saiphysics.com',$superPassword,'super_admin',null,0),
                    array('SAI Admin','admin@saiphysics.com','admin123','admin',$tenantId,1),
                    array('Physics Teacher','teacher@saiphysics.com','teacher123','teacher',$tenantId,1),
                    array('Demo Student','student@saiphysics.com','student123','student',$tenantId,1),
                );
                $userIds = array();
                foreach ($accounts as $a) {
                    $hash = password_hash($a[2], PASSWORD_DEFAULT);
                    $q = $pdo->prepare('SELECT id FROM users WHERE email=?'); $q->execute(array($a[1])); $uid = (int)$q->fetchColumn();
                    if ($uid) $pdo->prepare('UPDATE users SET tenant_id=?,name=?,password_hash=?,role=?,is_active=1,must_change_password=? WHERE id=?')->execute(array($a[4],$a[0],$hash,$a[3],$a[5],$uid));
                    else $uid = db_insert_id('INSERT INTO users (tenant_id,name,email,password_hash,role,is_active,must_change_password) VALUES (?,?,?,?,?,1,?)', array($a[4],$a[0],$a[1],$hash,$a[3],$a[5]));
                    $userIds[$a[3]] = $uid; if ($a[3] === 'teacher') ensure_teacher_code($uid, $pdo);
                }
                $q = $pdo->prepare('SELECT id FROM batches WHERE tenant_id=? AND session_id=? ORDER BY id'); $q->execute(array($tenantId,$sessionId)); $batchIds = $q->fetchAll(PDO::FETCH_COLUMN);
                if (count($batchIds) === 0) {
                    $batchIds[] = db_insert_id('INSERT INTO batches (tenant_id,session_id,name,class_name,subject,timing,room,fees_amount) VALUES (?,?,?,?,?,?,?,?)', array($tenantId,$sessionId,'Class 11 - Morning','Class 11','Physics','7:00 AM - 8:30 AM','Room A',1200));
                    $batchIds[] = db_insert_id('INSERT INTO batches (tenant_id,session_id,name,class_name,subject,timing,room,fees_amount) VALUES (?,?,?,?,?,?,?,?)', array($tenantId,$sessionId,'Class 12 - Evening','Class 12','Physics','5:00 PM - 6:30 PM','Room B',1500));
                }
                foreach ($batchIds as $i => $bid) {
                    $bid = (int)$bid;
                    $q = $pdo->prepare('SELECT id FROM classrooms WHERE batch_id=?'); $q->execute(array($bid));
                    if (!$q->fetchColumn()) $pdo->prepare('INSERT INTO classrooms (batch_id,tenant_id,session_id,title,created_by) VALUES (?,?,?,?,?)')->execute(array($bid,$tenantId,$sessionId,'Classroom - ' . ($i === 0 ? 'Class 11' : 'Class 12'),$userIds['admin']));
                    $q = $pdo->prepare('SELECT id FROM batch_teachers WHERE batch_id=? AND teacher_id=?'); $q->execute(array($bid,$userIds['teacher']));
                    if (!$q->fetchColumn()) $pdo->prepare('INSERT INTO batch_teachers (batch_id,teacher_id,assigned_by) VALUES (?,?,?)')->execute(array($bid,$userIds['teacher'],$userIds['admin']));
                }
                $q = $pdo->prepare('SELECT id FROM students WHERE tenant_id=? AND session_id=? AND admission_no=?'); $q->execute(array($tenantId,$sessionId,'SAI-001'));
                if (!$q->fetchColumn()) {
                    $registry = create_student_registry($tenantId, $sessionId, $pdo);
                    $pdo->prepare('INSERT INTO students (tenant_id,session_id,batch_id,user_id,registry_id,name,email,phone,guardian_name,admission_no,status,is_active) VALUES (?,?,?,?,?,?,?,?,?,?,?,1)')->execute(array($tenantId,$sessionId,(int)$batchIds[0],$userIds['student'],$registry['id'],'Demo Student','student@saiphysics.com','9876543210','Demo Guardian','SAI-001','active'));
                } else {
                    $q=$pdo->prepare('SELECT registry_id FROM students WHERE tenant_id=? AND session_id=? AND admission_no=?'); $q->execute(array($tenantId,$sessionId,'SAI-001')); $reg=(int)$q->fetchColumn();
                    if (!$reg) { $registry=create_student_registry($tenantId,$sessionId,$pdo); $pdo->prepare('UPDATE students SET registry_id=? WHERE tenant_id=? AND session_id=? AND admission_no=?')->execute(array($registry['id'],$tenantId,$sessionId,'SAI-001')); }
                }
                $pdo->prepare("INSERT INTO system_settings (setting_key,setting_value) VALUES ('setup_complete','1')")->execute();
                $pdo->commit();
                if (@file_put_contents(__DIR__ . '/storage/install.lock', 'installed ' . date('c') . PHP_EOL, LOCK_EX) === false) {
                    log_error('Could not write storage/install.lock; database setup_complete remains the primary installer lock.');
                }
                $done = true;
            } catch (Throwable $ex) { if ($pdo->inTransaction()) $pdo->rollBack(); $error = 'Setup could not be completed. Check that the database schema is current. Details are written to the PHP error log.'; log_error($ex->getMessage()); }
        }
    }
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Install SAI Physics v2.1</title><link rel="stylesheet" href="assets/app.css"></head><body class="login-page"><div class="card" style="width:min(520px,100%);padding:28px;border-radius:20px"><div class="eyebrow">FIRST-TIME SETUP</div><h1 style="font:800 25px Manrope;margin:0 0 10px">SAI Physics v2.1</h1><?php if ($done): ?><div class="alert success">Installation completed. Sign in using super@saiphysics.com and the password you created. Demo staff/student accounts are also ready.</div><a class="btn" href="login.php">Go to Login</a><?php elseif ($error): ?><div class="alert error"><?= e($error) ?></div><a class="btn secondary" href="install.php">Try again</a><?php else: ?><p class="muted">Create the platform Super Admin password. This one-time setup creates the sample institute, academic session and demo accounts.</p><form method="post"><div class="field"><label>Super Admin email</label><input value="super@saiphysics.com" disabled></div><div class="field"><label>Create Super Admin password *</label><input type="password" name="super_password" minlength="10" autocomplete="new-password" required></div><div class="field"><label>Confirm Super Admin password *</label><input type="password" name="confirm_password" minlength="10" autocomplete="new-password" required></div><?= csrf_field() ?><button class="btn" type="submit">Create Super Admin &amp; Install</button></form><p class="help-text" style="margin-top:16px">This page locks itself after the first successful installation. Run setup before making the website publicly accessible. Admin, Teacher and Student demo accounts are created with the credentials listed in README.md and must change their passwords at first login.</p><?php endif; ?></div></body></html>
