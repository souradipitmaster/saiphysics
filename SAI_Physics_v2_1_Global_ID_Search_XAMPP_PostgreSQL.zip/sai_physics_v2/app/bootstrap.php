<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-Frame-Options: SAMEORIGIN');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
}
if (session_status() !== PHP_SESSION_ACTIVE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    $cookiePath = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    if ($cookiePath === '') $cookiePath = '/'; else $cookiePath .= '/';
    session_set_cookie_params(array('lifetime' => 0, 'path' => $cookiePath, 'secure' => $secure, 'httponly' => true, 'samesite' => 'Lax'));
    ini_set('session.use_strict_mode', '1');
    session_start();
}
function e($value) { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function redirect($url) { header('Location: ' . $url); exit; }
function current_user() { return $_SESSION['user'] ?? null; }
function current_role() { $u = current_user(); return $u ? $u['role'] : ''; }
function current_tenant() {
    $u = current_user();
    if (!$u) return 0;
    if ($u['role'] === 'super_admin') return (int)($_SESSION['active_tenant_id'] ?? 0);
    return (int)$u['tenant_id'];
}
function current_session_id() {
    $tenant = current_tenant();
    if (!$tenant) return 0;
    // Only Super Admin may hold a per-workspace session override. Everyone else follows the institute's active session so a Super Admin switch takes effect for all users.
    if (current_role() === 'super_admin') {
        $chosen = (int)($_SESSION['active_session_id'] ?? 0);
        if ($chosen > 0) {
            $q = db()->prepare('SELECT id FROM sessions WHERE id = ? AND tenant_id = ?');
            $q->execute(array($chosen, $tenant));
            $valid = $q->fetchColumn();
            if ($valid) return (int)$valid;
        }
    }
    $q = db()->prepare('SELECT id FROM sessions WHERE tenant_id = ? ORDER BY is_current DESC, start_date DESC, id DESC LIMIT 1');
    $q->execute(array($tenant));
    $id = (int)$q->fetchColumn();
    $_SESSION['active_session_id'] = $id;
    return $id;
}
function current_tenant_row() {
    $id = current_tenant();
    if (!$id) return null;
    $q = db()->prepare('SELECT * FROM tenants WHERE id = ? AND is_active = 1');
    $q->execute(array($id));
    return $q->fetch() ?: null;
}
function require_login() { if (!current_user()) redirect('login.php'); }
function require_role($roles) {
    require_login();
    if (!in_array(current_role(), (array)$roles, true)) { http_response_code(403); exit('You do not have permission to access this page.'); }
}
function require_tenant_context() {
    require_login();
    if (!current_tenant() || !current_tenant_row()) {
        if (current_role() === 'super_admin') redirect('tenants.php');
        http_response_code(403); exit('This coaching institute is inactive or unavailable.');
    }
}
function can_access_batch($batchId, $write = false) {
    $batchId = (int)$batchId; $tenant = current_tenant(); $session = current_session_id();
    if (!$tenant || !$batchId) return false;
    $role = current_role();
    if ($role === 'super_admin' || $role === 'admin') {
        $q = db()->prepare('SELECT id FROM batches WHERE id = ? AND tenant_id = ? AND session_id = ?');
        $q->execute(array($batchId, $tenant, $session)); return (bool)$q->fetchColumn();
    }
    if ($role === 'teacher') {
        $q = db()->prepare('SELECT b.id FROM batches b JOIN batch_teachers bt ON bt.batch_id=b.id WHERE b.id=? AND b.tenant_id=? AND b.session_id=? AND bt.teacher_id=?');
        $q->execute(array($batchId, $tenant, $session, current_user()['id'])); return (bool)$q->fetchColumn();
    }
    if ($role === 'student' && !$write) {
        $q = db()->prepare('SELECT id FROM students WHERE batch_id=? AND tenant_id=? AND session_id=? AND user_id=? AND is_active=1');
        $q->execute(array($batchId, $tenant, $session, current_user()['id'])); return (bool)$q->fetchColumn();
    }
    return false;
}
function csrf_token() { if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32)); return $_SESSION['_csrf']; }
function csrf_field() { return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">'; }
function csrf_check() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $sent = $_POST['_csrf'] ?? '';
        if (!$sent || !hash_equals(csrf_token(), $sent)) { http_response_code(419); exit('Your form session expired. Please go back, refresh and try again.'); }
    }
}
function flash($type, $message) { $_SESSION['_flash'] = array('type' => $type, 'message' => $message); }
function get_flash() { $f = $_SESSION['_flash'] ?? null; unset($_SESSION['_flash']); return $f; }
function money($v) { return '₹' . number_format((float)$v, 2); }
function post_string($key, $max = 255) { return trim(substr((string)($_POST[$key] ?? ''), 0, $max)); }
function valid_amount($value) { return is_numeric($value) && is_finite((float)$value) && (float)$value >= 0; }
function valid_date_value($value) { if ($value === null || $value === '') return true; $value=(string)$value; $date=DateTime::createFromFormat('!Y-m-d',$value); return $date instanceof DateTime && $date->format('Y-m-d') === $value; }
function encrypt_video_id($videoId) {
    if (!preg_match('/^[A-Za-z0-9_-]{11}$/', $videoId)) throw new InvalidArgumentException('Enter a valid 11-character YouTube video ID.');
    $key = hash('sha256', APP_KEY, true); $iv = random_bytes(12); $tag = '';
    $cipher = openssl_encrypt($videoId, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
    if ($cipher === false) throw new RuntimeException('Could not protect video ID.');
    return base64_encode($iv . $tag . $cipher);
}
function decrypt_video_id($encoded) {
    $raw = base64_decode((string)$encoded, true);
    if ($raw === false || strlen($raw) < 29) throw new RuntimeException('Stored video ID is invalid.');
    $plain = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', hash('sha256', APP_KEY, true), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
    if ($plain === false || !preg_match('/^[A-Za-z0-9_-]{11}$/', $plain)) throw new RuntimeException('Video ID could not be decrypted. Check APP_KEY.');
    return $plain;
}

function create_student_registry($tenantId, $sessionId, $pdo = null) {
    $pdo = $pdo ?: db();
    $registryId = db_insert_id('INSERT INTO student_registry (tenant_id, student_code) VALUES (?, ?)', array((int)$tenantId, null));
    $q = $pdo->prepare('SELECT start_date, name FROM sessions WHERE id = ? AND tenant_id = ?');
    $q->execute(array((int)$sessionId, (int)$tenantId));
    $sessionRow = $q->fetch() ?: array();
    $year = '';
    if (!empty($sessionRow['start_date'])) $year = substr((string)$sessionRow['start_date'], 0, 4);
    if (!preg_match('/^20[0-9]{2}$/', $year) && !empty($sessionRow['name']) && preg_match('/(20[0-9]{2})/', $sessionRow['name'], $m)) $year = $m[1];
    if (!preg_match('/^20[0-9]{2}$/', $year)) $year = date('Y');
    $code = 'S-' . str_pad((string)$registryId, 4, '0', STR_PAD_LEFT) . '-' . $year;
    $pdo->prepare('UPDATE student_registry SET student_code = ? WHERE id = ? AND tenant_id = ?')->execute(array($code, $registryId, (int)$tenantId));
    return array('id' => $registryId, 'code' => $code);
}
function ensure_teacher_code($userId, $pdo = null) {
    $pdo = $pdo ?: db();
    $q = $pdo->prepare('SELECT teacher_code, role FROM users WHERE id = ?');
    $q->execute(array((int)$userId));
    $row = $q->fetch();
    if (!$row || $row['role'] !== 'teacher') return null;
    if (!empty($row['teacher_code'])) return $row['teacher_code'];
    $code = 'T-' . str_pad((string)(int)$userId, 4, '0', STR_PAD_LEFT);
    $pdo->prepare("UPDATE users SET teacher_code = ? WHERE id = ? AND role = 'teacher'")->execute(array($code, (int)$userId));
    return $code;
}

function log_error($message) { error_log('[SAI Physics] ' . $message); }
function require_student_own_fee($feeId) {
    $q = db()->prepare('SELECT sf.*, s.name AS student_name, s.user_id FROM student_fees sf JOIN students s ON s.id=sf.student_id WHERE sf.id=? AND sf.tenant_id=? AND sf.session_id=?');
    $q->execute(array((int)$feeId, current_tenant(), current_session_id()));
    $row = $q->fetch();
    if (!$row) return null;
    if (current_role() === 'student' && (int)$row['user_id'] !== (int)current_user()['id']) return null;
    if (!in_array(current_role(), array('super_admin', 'admin', 'student'), true)) return null;
    return $row;
}
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') csrf_check();
// Revalidate account and tenant activation on each request so a disabled account loses access immediately.
if (current_user()) {
    try {
        $check = db()->prepare('SELECT u.id,u.tenant_id,u.name,u.email,u.role,u.is_active,u.must_change_password,COALESCE(t.is_active,1) AS tenant_active FROM users u LEFT JOIN tenants t ON t.id=u.tenant_id WHERE u.id=?');
        $check->execute(array(current_user()['id'])); $fresh = $check->fetch();
        if (!$fresh || (int)$fresh['is_active'] !== 1 || (int)$fresh['tenant_active'] !== 1) {
            $_SESSION = array(); session_destroy(); redirect('login.php');
        }
        $_SESSION['user'] = $fresh;
    } catch (Throwable $ex) { log_error($ex->getMessage()); http_response_code(503); exit('Unable to validate your account. Please try again later.'); }
}
if (current_user() && !empty(current_user()['must_change_password'])) {
    $currentPage = basename($_SERVER['PHP_SELF'] ?? '');
    if (!in_array($currentPage, array('account.php','logout.php'), true)) redirect('account.php');
}
