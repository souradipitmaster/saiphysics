<?php
/**
 * CLI-only one-time data copy from the MySQL installation into an EMPTY PostgreSQL database.
 * Configure MIGRATE_MYSQL_* and MIGRATE_PGSQL_* environment variables first.
 * Usage: php tools/migrate_mysql_to_postgresql.php [--truncate]
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit("CLI only.\n"); }
error_reporting(E_ALL); ini_set('display_errors','1');
$tables=array('tenants','sessions','users','student_registry','batches','batch_teachers','students','batch_transfers','fees','student_fees','payments','payment_orders','classrooms','classroom_videos','classroom_materials','attendance','exams','exam_marks','system_settings');
$mysqlHost=getenv('MIGRATE_MYSQL_HOST')?:'127.0.0.1';$mysqlPort=getenv('MIGRATE_MYSQL_PORT')?:'3306';$mysqlDb=getenv('MIGRATE_MYSQL_DB')?:'sai_physics';$mysqlUser=getenv('MIGRATE_MYSQL_USER')?:'root';$mysqlPass=getenv('MIGRATE_MYSQL_PASS')?:'';
$pgHost=getenv('MIGRATE_PGSQL_HOST')?:'127.0.0.1';$pgPort=getenv('MIGRATE_PGSQL_PORT')?:'5432';$pgDb=getenv('MIGRATE_PGSQL_DB')?:'sai_physics';$pgUser=getenv('MIGRATE_PGSQL_USER')?:'postgres';$pgPass=getenv('MIGRATE_PGSQL_PASS')?:'';
try {
 $source=new PDO('mysql:host='.$mysqlHost.';port='.$mysqlPort.';dbname='.$mysqlDb.';charset=utf8mb4',$mysqlUser,$mysqlPass,array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC));
 $target=new PDO('pgsql:host='.$pgHost.';port='.$pgPort.';dbname='.$pgDb,$pgUser,$pgPass,array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC));
 $truncate=in_array('--truncate',$argv,true);
 foreach($tables as $table){$n=(int)$target->query('SELECT COUNT(*) FROM "'.$table.'"')->fetchColumn();if($n>0&&!$truncate)throw new RuntimeException('Target table '.$table.' is not empty. Use a fresh database or explicitly pass --truncate.');}
 $target->beginTransaction();
 if($truncate){$quoted=array_map(function($t){return '"'.$t.'"';},$tables);$target->exec('TRUNCATE TABLE '.implode(',',$quoted).' RESTART IDENTITY CASCADE');}
 $total=0;
 foreach($tables as $table){
  $rows=$source->query('SELECT * FROM `'.$table.'`');$columns=array();$insert=null;$count=0;
  while($row=$rows->fetch()){
   if(!$columns){$columns=array_keys($row);$quoted=array_map(function($c){return '"'.str_replace('"','""',$c).'"';},$columns);$marks=implode(',',array_fill(0,count($columns),'?'));$insert=$target->prepare('INSERT INTO "'.$table.'" ('.implode(',',$quoted).') VALUES ('.$marks.')');}
   $insert->execute(array_values($row));$count++;$total++;
  }
  echo str_pad($table,24).$count." row(s)\n";
 }
 foreach($tables as $table){if($table==='system_settings')continue;$max=$target->query('SELECT MAX(id) FROM "'.$table.'"')->fetchColumn();$seq=$target->prepare("SELECT pg_get_serial_sequence(?, 'id')");$seq->execute(array($table));$sequence=$seq->fetchColumn();if($sequence){$stmt=$target->prepare('SELECT setval(CAST(? AS regclass), CAST(? AS bigint), CAST(? AS boolean))');$stmt->execute(array($sequence,$max===null?1:(int)$max,$max!==null?'true':'false'));}}
 $target->commit();echo "\nMigration completed. Total copied rows: ".$total."\n";
} catch(Throwable $e){if(isset($target)&&$target->inTransaction())$target->rollBack();fwrite(STDERR,"Migration failed: ".$e->getMessage()."\n");exit(1);}
