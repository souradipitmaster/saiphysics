/* Optional browser-level deterrents for classroom playback. Not DRM. */
(function(){
  document.addEventListener('contextmenu',function(e){e.preventDefault();});
  document.addEventListener('dragstart',function(e){e.preventDefault();});
  document.addEventListener('keydown',function(e){
    var key=(e.key||'').toLowerCase();
    if(e.key==='PrintScreen'){
      var hint=document.getElementById('capture-warning');
      if(hint){hint.hidden=false;window.setTimeout(function(){hint.hidden=true;},1800);}
    }
    if((e.ctrlKey||e.metaKey)&&['p','s','u'].indexOf(key)>=0)e.preventDefault();
    if(e.key==='F12'||(e.ctrlKey&&e.shiftKey&&['i','j','c'].indexOf(key)>=0))e.preventDefault();
  });
})();
