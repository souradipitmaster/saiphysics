(function(){
  'use strict';
  var deferredPrompt=null;
  var isIOS=/iphone|ipad|ipod/i.test(navigator.userAgent);
  var standalone=window.matchMedia('(display-mode: standalone)').matches||window.navigator.standalone===true;
  function removeBanner(){var el=document.getElementById('install-banner');if(el)el.remove();}
  function showBanner(ios){if(standalone||document.getElementById('install-banner'))return;var box=document.createElement('div');box.id='install-banner';box.style.cssText='position:fixed;left:14px;right:14px;bottom:14px;z-index:9999;background:#17234a;color:#fff;padding:16px 18px;border-radius:16px;box-shadow:0 15px 40px #10193655;font-family:system-ui,sans-serif;text-align:left';
    var title=document.createElement('strong');title.textContent='Install SAI Physics';title.style.display='block';title.style.marginBottom='5px';
    var copy=document.createElement('div');copy.textContent=ios?'Tap Share, then Add to Home Screen to install.':'Install the app for a faster, app-like learning experience.';copy.style.cssText='font-size:12px;color:#c5cfee;margin-bottom:12px;line-height:1.5';
    var install=document.createElement('button');install.textContent=ios?'How to install':'Install app';install.style.cssText='background:#8874ff;color:#fff;border:0;border-radius:9px;padding:9px 13px;font-weight:700;margin-right:8px';
    var later=document.createElement('button');later.textContent='Later';later.style.cssText='background:transparent;color:#d8ddf1;border:1px solid #65729a;border-radius:9px;padding:9px 13px';later.onclick=removeBanner;
    install.onclick=async function(){if(ios){window.alert('In Safari, tap the Share button, choose “Add to Home Screen”, then tap Add.');return;}if(deferredPrompt){deferredPrompt.prompt();var choice=await deferredPrompt.userChoice;if(choice&&choice.outcome==='accepted')removeBanner();deferredPrompt=null;}else{window.alert('Open the browser menu and choose Install app or Add to Home Screen.');}};
    box.appendChild(title);box.appendChild(copy);box.appendChild(install);box.appendChild(later);document.body.appendChild(box);
  }
  window.addEventListener('beforeinstallprompt',function(e){e.preventDefault();deferredPrompt=e;if(!standalone)setTimeout(function(){showBanner(false);},800);});
  window.addEventListener('appinstalled',removeBanner);
  window.addEventListener('load',function(){if(isIOS&&!standalone)setTimeout(function(){showBanner(true);},1800);});
})();
