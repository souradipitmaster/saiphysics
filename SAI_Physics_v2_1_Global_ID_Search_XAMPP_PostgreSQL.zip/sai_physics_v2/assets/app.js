(function(){
  var toggle=document.getElementById('menu-toggle'), sidebar=document.getElementById('sidebar');
  if(toggle&&sidebar) toggle.addEventListener('click',function(){sidebar.classList.toggle('open');});
  document.addEventListener('click',function(ev){if(window.innerWidth<=760&&sidebar&&sidebar.classList.contains('open')&&!sidebar.contains(ev.target)&&toggle&&!toggle.contains(ev.target))sidebar.classList.remove('open');});
  document.querySelectorAll('[data-confirm]').forEach(function(el){el.addEventListener('click',function(ev){if(!window.confirm(el.getAttribute('data-confirm')||'Are you sure?'))ev.preventDefault();});});
  document.querySelectorAll('[data-search-target]').forEach(function(input){input.addEventListener('input',function(){var target=document.querySelector(input.getAttribute('data-search-target'));if(!target)return;var q=input.value.toLowerCase();target.querySelectorAll('tbody tr').forEach(function(row){row.style.display=row.textContent.toLowerCase().indexOf(q)>=0?'':'none';});});});
  if('serviceWorker' in navigator && location.protocol!=='file:'){window.addEventListener('load',function(){navigator.serviceWorker.register(new URL('sw.js',document.baseURI).toString()).catch(function(){});});}
})();
