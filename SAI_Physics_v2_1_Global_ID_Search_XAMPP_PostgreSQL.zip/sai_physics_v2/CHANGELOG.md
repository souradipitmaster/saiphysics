# SAI Physics v2.0 · Rebuild notes

- Replaced MySQLi-only access with PDO and a driver switch for MySQL/PostgreSQL.
- Added separate MySQL and PostgreSQL schemas plus a CLI data migration utility.
- Reworked the interface into a responsive, vibrant SaaS dashboard.
- Added tenant context selection and tenant/session validation to major workflows.
- Replaced publicly accessible password-reset installer with a one-time key-protected installer.
- Enforced a first-login password change for demo accounts.
- Added CSRF validation, prepared queries, password hashing, secure session settings and escaped output helpers.
- Added student admissions/login linking, batch transfer, promotion, graduation/left and account enable/disable.
- Rebuilt fee generation, adjustments and offline collection with transaction/overpayment validation.
- Added server-side Razorpay order/signature/capture verification (disabled by default).
- Added classroom video ID encryption with AES-256-GCM, classroom materials and permission-checked downloads.
- Added attendance marking and test/marks entry with student result views.
- Rebuilt PWA paths/cache behavior so install paths are not hardcoded and private pages are not cached.
- Added indexes and bounded list queries for common dashboard screens.


## v2.1 - 2026-11-17
- Added permanent student identity registry and case-insensitive Student ID lookup (`S-XXXX-YYYY`).
- Added teacher IDs (`T-XXXX`) and automatic ID assignment.
- Added topbar global search and detailed student/teacher profile pages.
- Profile pages show all linked session enrolments, fee totals, paid amounts, attendance counts, assessment counts and teacher batch assignments.
- Search permissions are tenant- and role-scoped; exact ID lookup only.
- Added MySQL and PostgreSQL upgrade scripts for existing v2.0 databases.
